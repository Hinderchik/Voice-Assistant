using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.OS;
using Android.Runtime;
using Android.Speech;
using Android.Widget;
using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace VoiceAssistantApp
{
    [Activity(Label = "Голосовой ассистент", MainLauncher = true, Icon = "@mipmap/icon")]
    public class MainActivity : Activity
    {
        private Button startButton;
        private Button stopButton;
        private TextView statusText;
        private TextView resultText;
        private bool isListening = false;
        private SpeechRecognizer speechRecognizer;
        private Intent speechIntent;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.Main);

            // Проверяем разрешения
            CheckPermissions();

            // Инициализируем элементы UI
            startButton = FindViewById<Button>(Resource.Id.startButton);
            stopButton = FindViewById<Button>(Resource.Id.stopButton);
            statusText = FindViewById<TextView>(Resource.Id.statusText);
            resultText = FindViewById<TextView>(Resource.Id.resultText);

            // Настраиваем обработчики кнопок
            startButton.Click += StartListening;
            stopButton.Click += StopListening;
            stopButton.Enabled = false;

            // Инициализируем распознаватель речи
            speechRecognizer = SpeechRecognizer.CreateSpeechRecognizer(this);
            speechRecognizer.Recognition += SpeechRecognizer_Recognition;

            // Создаем intent для распознавания речи
            speechIntent = new Intent(RecognizerIntent.ActionRecognizeSpeech);
            speechIntent.PutExtra(RecognizerIntent.ExtraLanguageModel, RecognizerIntent.LanguageModelFreeForm);
            speechIntent.PutExtra(RecognizerIntent.ExtraLanguage, Java.Util.Locale.Default);
            speechIntent.PutExtra(RecognizerIntent.ExtraPartialResults, true);
            speechIntent.PutExtra(RecognizerIntent.ExtraSpeechInputCompleteSilenceLengthMillis, 1500);
            speechIntent.PutExtra(RecognizerIntent.ExtraSpeechInputPossiblyCompleteSilenceLengthMillis, 1500);
            speechIntent.PutExtra(RecognizerIntent.ExtraSpeechInputMinimumLengthMillis, 10000);
            speechIntent.PutExtra(RecognizerIntent.ExtraMaxResults, 1);
        }

        private void CheckPermissions()
        {
            if (CheckSelfPermission(Android.Manifest.Permission.RecordAudio) != Permission.Granted)
            {
                RequestPermissions(new string[] { Android.Manifest.Permission.RecordAudio }, 1);
            }
        }

        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Permission[] grantResults)
        {
            base.OnRequestPermissionsResult(requestCode, permissions, grantResults);

            if (requestCode == 1)
            {
                if (grantResults.Length > 0 && grantResults[0] == Permission.Granted)
                {
                    Toast.MakeText(this, "Разрешение на использование микрофона получено", ToastLength.Short).Show();
                }
                else
                {
                    Toast.MakeText(this, "Для работы приложения необходимо разрешение на использование микрофона", ToastLength.Long).Show();
                }
            }
        }

        private void StartListening(object sender, EventArgs e)
        {
            if (!isListening)
            {
                isListening = true;
                startButton.Enabled = false;
                stopButton.Enabled = true;
                statusText.Text = "Слушаю...";
                
                // Запускаем распознавание
                speechRecognizer.StartListening(speechIntent);
            }
        }

        private void StopListening(object sender, EventArgs e)
        {
            if (isListening)
            {
                isListening = false;
                startButton.Enabled = true;
                stopButton.Enabled = false;
                statusText.Text = "Остановлено";
                
                // Останавливаем распознавание
                speechRecognizer.StopListening();
            }
        }

        private void SpeechRecognizer_Recognition(object sender, RecognitionEventArgs e)
        {
            var stopwatch = Stopwatch.StartNew();
            
            RunOnUiThread(() =>
            {
                var results = e.Results.GetStringArrayList(SpeechRecognizer.ResultsRecognition);
                
                if (results != null && results.Count > 0)
                {
                    string text = results[0];
                    stopwatch.Stop();
                    
                    // Выводим результат с временем обработки
                    resultText.Text = $"{text} '{stopwatch.ElapsedMilliseconds}мс'";
                    
                    // Если есть слово "Джарвис", выполняем действие
                    if (text.ToLower().Contains("джарвис"))
                    {
                        // Здесь можно добавить любые действия
                        Toast.MakeText(this, "Команда получена!", ToastLength.Short).Show();
                    }
                    
                    // Продолжаем слушать
                    if (isListening)
                    {
                        speechRecognizer.StartListening(speechIntent);
                    }
                }
                else if (isListening)
                {
                    // Продолжаем слушать, даже если нет результатов
                    speechRecognizer.StartListening(speechIntent);
                }
            });
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();
            if (speechRecognizer != null)
            {
                speechRecognizer.Destroy();
                speechRecognizer = null;
            }
        }
    }
}